#!/bin/sh

./fv banner2.jpg

