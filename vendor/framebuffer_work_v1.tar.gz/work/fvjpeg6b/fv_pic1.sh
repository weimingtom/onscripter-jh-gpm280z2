#!/bin/sh

./fv pic1.jpg

