#!/bin/sh

./fv banner.jpg

