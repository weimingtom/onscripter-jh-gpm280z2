#!/bin/sh

../onscripter-jh/onscripter

